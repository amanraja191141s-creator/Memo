# SA Calculator v98.54 — Approved Neon Home replacement

The previous v98.53 Home presentation layer has been removed from the active CSS build chain and replaced by `assets/css/rebuild-v98.54.css`. Existing calculator markup, `data-calc` hooks, calculation engine and navigation event IDs are preserved.

## Reference-matched composition
- Header: hamburger, SA Calculator brand mark/title, history action and overflow menu.
- Display: open borderless navy display with blue wave artwork; expression and result remain visible together after evaluation.
- Keypad: four columns and five rows, zero spans two columns, blue AC/operator/equal keys, dark numeric keys.
- Navigation: five equal destinations with neon cyan active indicator and glow.
- System bars: remain Android-native; app content uses safe-area-aware sizing.

## Responsive geometry
- Header: 70 CSS px (58px on short-height screens, 64px on compact width).
- Display: 29% of Home viewport (27% compact width, 24% short-height).
- Keypad: remaining viewport, five equal rows, 7px gaps (5px compact/short-height).
- Navigation: 76px (72px compact, 68px short-height).
- All calculator keys preserve at least 48px minimum touch dimensions.

## Behavior preserved
All original `data-calc` values and IDs remain unchanged. Header history, overflow/drawer, five-tab navigation, settings, history, favorites, tool routing and calculator input handlers retain their existing JS bindings.

## Verification boundary
Automated source, syntax, regression, bundle and ZIP checks are run in the supplied release environment. Physical Android screenshot comparison, APK installation and device performance require a real device/build runner and are not claimed as completed here.

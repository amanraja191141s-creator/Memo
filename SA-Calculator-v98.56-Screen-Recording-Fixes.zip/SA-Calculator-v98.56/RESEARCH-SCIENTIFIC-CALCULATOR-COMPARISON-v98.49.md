# Scientific Calculator Feature Comparison — v98.49

Reviewed public feature listings for HiPER Scientific Calculator, TechCalc, Scientific Calculator (Philip Stephens), and Android accessibility guidance. Competitor feature listings commonly include textbook-style expressions, trig/hyperbolic functions, logarithms, roots/powers, fractions, memory/history, complex numbers, matrices, statistics, base conversion, graphing, integrals and derivatives. Google accessibility guidance recommends 48dp minimum touch targets where practical.

SA Calculator v98.49 now presents the existing supported subset in a reference-inspired layout: constants, trig/inverse trig, hyperbolic trig, powers, roots, logs, factorial, absolute value, scientific exponent entry, angle mode, memory, history and editing. Complex numbers, matrices, calculus, graphing, OCR, base-N programmer functions and symbolic algebra are not implemented by the current engine and are intentionally not shown as working buttons.

Sources: https://play.google.com/store/apps/details?id=cz.hipercalc ; https://play.google.com/store/apps/details?id=com.roamingsquirrel.android.calculator ; https://play.google.com/store/apps/details?id=stephenssoftware.scientificcalculatorprof ; https://support.google.com/accessibility/android/answer/7101858

# v98.54 — Home root-cause rebuild

- Removed the v98.50 global header suppression that hid the approved Home header despite the v98.52 header styling.
- Removed redundant v98.50 Home keypad overrides; Home sizing is now owned by the v98.54 authoritative layer.
- Removed the v98.52 Home stylesheet from the active Android CSS source chain.
- Rebuilt Home header, display, keypad and five-item bottom navigation to match the approved reference proportions more closely.
- Header is shown on Home and Tools; child tools, Favorites and Settings use their contextual toolbar without the global header.
- Fixed bottom-navigation `[hidden]` specificity so it actually disappears on child tool screens.
- Preserved all existing calculation `data-calc` hooks, expression/result IDs, JavaScript calculation handlers, History action and tool navigation behavior.
- Bumped package/runtime/manifest/cache/workflow identity to `1.98.54-v98.54` / `1098054`.
